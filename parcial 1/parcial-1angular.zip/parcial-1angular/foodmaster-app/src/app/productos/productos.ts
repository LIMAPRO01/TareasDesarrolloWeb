import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

interface Producto {
  nombre: string;
  precio: number;
  descripcion: string;
  imagen: string;
}

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatButtonModule],
  templateUrl: './productos.html',
  styleUrls: ['./productos.css'],
})
export class ProductosComponent {
  productos: Producto[] = [
    { nombre: 'Café Americano', precio: 12, descripcion: 'Taza de café filtrado.', imagen: 'https://www.cubaneandoconmario.com/wp-content/uploads/2017/01/Caf%C3%A9-americano.jpg' },
    { nombre: 'Capuchino', precio: 18, descripcion: 'Espresso con leche espumosa.', imagen: 'https://www.clarin.com/img/2022/03/01/ceq4FUBv9_2000x1500__1.jpg' },
    { nombre: 'Latte', precio: 20, descripcion: 'Espresso con leche cremosa.', imagen: 'https://www.foodandwine.com/thmb/CCe2JUHfjCQ44L0YTbCu97ukUzA=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Partners-Latte-FT-BLOG0523-09569880de524fe487831d95184495cc.jpg' },
    { nombre: 'Té Verde', precio: 10, descripcion: 'Infusión ligera y fresca.', imagen: 'https://www.lavanguardia.com/files/og_thumbnail/uploads/2021/05/21/60a779bd0b14c.jpeg' },
    { nombre: 'Jugo de Naranja', precio: 15, descripcion: 'Natural recién exprimido.', imagen: 'https://s3-sa-east-1.amazonaws.com/producto.locoporlacocina/wp-content/uploads/2023/12/Naranjas1.png' },
    { nombre: 'Sandwich Jamón/Queso', precio: 22, descripcion: 'Pan blanco, jamón y queso.', imagen: 'https://tse2.mm.bing.net/th/id/OIP.LMemw2INQYPCjnDaht2dJwHaEQ?rs=1&pid=ImgDetMain&o=7&rm=3' },
    { nombre: 'Panini de Pollo', precio: 25, descripcion: 'Panini caliente con pollo.', imagen: 'https://cocinamia.com.mx/wp-content/uploads/2020/02/a-63-1-1100x500.png' },
    { nombre: 'Ensalada César', precio: 28, descripcion: 'Lechuga, aderezo y crutones.', imagen: 'https://www.gourmet.cl/wp-content/uploads/2016/09/Ensalada_C%C3%A9sar-web-553x458.jpg' },
    { nombre: 'Brownie', precio: 14, descripcion: 'Chocolate intenso.', imagen: 'https://th.bing.com/th/id/R.d9f89ebfd694ffb9bd30121c0f0f66b3?rik=GoAYQd6NBb%2bYMA&pid=ImgRaw&r=0' },
    { nombre: 'Galleta', precio: 8, descripcion: 'Galleta horneada del día.', imagen: 'https://s.tmimgcdn.com/scr/1200x627/422800/diferentes-etapas-de-la-galleta-consumida-galletas-con-chispas-de-chocolate-53_422835-original.jpg' },
    { nombre: 'Yogurt con Granola', precio: 16, descripcion: 'Yogurt natural y frutas.', imagen: 'https://th.bing.com/th/id/R.7c3beb8f1221e1558aab573c8fdf8665?rik=qs%2bwXirhrwmC2w&pid=ImgRaw&r=0' },
    { nombre: 'Agua Pura', precio: 6, descripcion: 'Botella 600 ml.', imagen: 'https://th.bing.com/th/id/R.97087f17ec824ddc1c5351de6f1ad9c1?rik=9nlLlTVV%2bmAbQg&riu=http%3a%2f%2fbasicos.mayoreoenlinea.mx%2fcdn%2fshop%2fproducts%2f7501086801121.jpg%3fv%3d1699396084&ehk=QA5xmJ3Y2lSEpV7FH00kvtn5PWZOXjGb2cllOlr1cZ4%3d&risl=&pid=ImgRaw&r=0' },
  ];

  agregarAlCarrito(p: Producto) {
    alert(`El producto ${p.nombre} ha sido agregado al carrito.`);
  }
}
