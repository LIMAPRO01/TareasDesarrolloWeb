import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  __commonJS
} from "./chunk-6DU2HRTW.js";

// optional-peer-dep:__vite-optional-peer-dep:@angular/animations/browser:@angular/platform-browser:false
var require_platform_browser_false = __commonJS({
  "optional-peer-dep:__vite-optional-peer-dep:@angular/animations/browser:@angular/platform-browser:false"(exports, module) {
    module.exports = {};
    throw new Error(`Could not resolve "@angular/animations/browser" imported by "@angular/platform-browser". Is it installed?`);
  }
});
export default require_platform_browser_false();
//# sourceMappingURL=platform-browser_false-233L5KXB.js.map
