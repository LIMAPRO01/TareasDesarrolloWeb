import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-XQQ2F7YT.js";
import "./chunk-BWLR3LOX.js";
import "./chunk-6DU2HRTW.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
